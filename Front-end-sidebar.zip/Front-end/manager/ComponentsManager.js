
class SideBar extends HTMLElement {
    constructor() {
        super();
    }

    connectedCallback() {
    this.innerHTML = ` <div class="btn">
    <span class="fas fa-bars"  style="color: #ffffff";></span>
 </div>
 <nav class="sidebar">
    <div class="text">
       Side Menu
    </div>
    <ul>
       <li class="active"><a href="#">Profile</a></li>
       <li ><a href="#">Login/SignUp</a></li>
       
       <li>
          <a href="#" class="serv-btn">Our Services
          <span class="fas fa-caret-down second"></span>
          </a>
          <ul class="serv-show">
             <li><a href="#">GYM Memberships</a></li>
             <li><a href="#">SPA</a></li>
             <li><a href="#">CLASSES</a></li>
             
          </ul>
       </li>
       <li><a href="#footer">Announcments</a></li>
       <li><a href="#footer">Contact Us</a></li>
       
    </ul>
 </nav>

    `
    $('.btn').click(function(){
      $(this).toggleClass("click");
      $('.sidebar').toggleClass("show");
    });
      $('.feat-btn').click(function(){
        $('nav ul .feat-show').toggleClass("show");
        $('nav ul .first').toggleClass("rotate");
      });
      $('.serv-btn').click(function(){
        $('nav ul .serv-show').toggleClass("show1");
        $('nav ul .second').toggleClass("rotate");
      });
      $('nav ul li').click(function(){
        $(this).addClass("active").siblings().removeClass("active");
      });;
    }

   
}



customElements.define('side-bar', SideBar);